//Archivo que se va a dedicar a correr la rutina de administración de bicicletas

import java.util.Scanner;
public class Proceso {
    public static Bicicleta crearBicicleta(){

        Scanner myObj = new Scanner(System.in);

        String marca, cambios, rodaje;
        type aType;
        size aSize;

        System.out.println("Ingrese marca");
        marca = myObj.nextLine();
        System.out.println("Ingrese cambios");
        cambios = myObj.nextLine();
        System.out.println("Ingrese un rodaje (26,27.5 o 29)");
        rodaje = myObj.nextLine();
        System.out.println("Ingrese un tipo de bicicleta (1:MTB, 2:Ruta, 3:City, 4:Utilitaria)");
        switch(myObj.nextInt()){
            case 1:
                aType = type.MTB;
                break;
            case 2:
                aType = type.Ruta;
                break;
            case 4:
                aType = type.Utilitaria;
                break;
            default:
                aType = type.City;
                break;
        }
        System.out.println("Ingrese un tamanio de bicicleta (1:XS, 2:S, 3:M, 4:L, 5:XL)");

        switch(myObj.nextInt()){
            case 1:
                aSize = size.XS;
                break;
            case 2:
                aSize = size.S;
                break;
            case 4:
                aSize = size.L;
                break;
            case 5:
                aSize = size.XL;
                break;
            default:
                aSize = size.M;
                break;
        }
        Bicicleta bici = new Bicicleta(cambios,rodaje,marca,aType,aSize);
        return bici;
    }
}
