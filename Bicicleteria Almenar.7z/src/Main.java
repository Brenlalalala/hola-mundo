import java.util.Scanner;
import java.util.List;
import java.util.ArrayList;
public class Main {
    public static void main(String[] args) {

            List<Bicicleta> misBicis = new ArrayList<Bicicleta>();

            Scanner scanner = new Scanner(System.in);

            boolean option = false;

            while(!option){
                option = false;
                System.out.println("\n1- Agregar bici, 2- Lavar bicis, 3- Mantener bicis, 4- Usar bicis, 5- Ver bicis 0-Terminar");
                switch(scanner.nextInt()){
                    case 1:
                        misBicis.add(Proceso.crearBicicleta());
                        break;
                    case 2:
                        for(Bicicleta bici: misBicis){
                            bici.lavarBici();
                        }
                        break;
                    case 3:
                        for(Bicicleta bici: misBicis){
                            bici.mantenerBici();
                        }
                        break;
                    case 4:
                        for(Bicicleta bici: misBicis){
                            bici.usarBici();
                        }
                        break;
                    case 5:
                        for(Bicicleta bici: misBicis){
                            System.out.println(bici);
                        }
                        break;
                    default:
                        option = true;
                        break;
                }
            }

    }
}