import java.io.Serializable;
// Enum que almacenan las opciones disponibles de tipo y de tamaño
enum type {
    MTB,Ruta,City,Utilitaria
}
enum size{
    XS,S,M,L,XL
}
public class Bicicleta implements Serializable {
    private String marca, cambios, rodaje;
    private type aType;
    private size aSize;

    public Bicicleta() {
    }

    public Bicicleta(String cambios, String rodaje, String marca, type aType, size aSize) {
        this.rodaje = rodaje;
        this.cambios = cambios;
        this.marca = marca;
        this.aType = aType;
        this.aSize = aSize;
    }

    public String getCambios() {
        return cambios;
    }

    public void setCambios(String cambios) {
        this.cambios = cambios;
    }

    public String getRodaje() {
        return rodaje;
    }

    public void setRodaje(String rodaje) {
        this.rodaje = rodaje;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public type getaType() {
        return aType;
    }

    public void setaType(type aType) {
        this.aType = aType;
    }

    public size getaSize() {
        return aSize;
    }

    public void setaSize(size aSize) {
        this.aSize = aSize;
    }

    // Sobreescribe toString para que muestre detalladamente todos los datos del objeto
    @Override
    public String toString(){
        return ("Bicicleta marca \"" + this.marca + "\" con " + this.cambios + " cambios, con un cuadro " + this.aSize + " de tipo " + this.aType + " con un rodaje de " + this.rodaje + "\"");
    }

    public void lavarBici(){
        System.out.println("La " + this.toString() + " ha sido lavada!");
    }
    public void usarBici(){
        System.out.println("La " + this.toString() + " ha sido usada!");
    }
    public void mantenerBici(){
        System.out.println("A la " + this.toString() + " se le ha hecho mantenimiento!");
    }


}
